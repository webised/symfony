<?php

namespace Ng\CoreBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class NgCoreBundle extends Bundle
{
}
